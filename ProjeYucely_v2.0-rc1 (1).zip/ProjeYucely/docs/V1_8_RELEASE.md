# ProjeYucely v1.8

## Commerce completion chain

This release connects the sandbox commerce lifecycle end to end:

1. Customer/requester funds a job.
2. Provider intent succeeds in mock/sandbox mode.
3. Funds are placed in escrow with idempotency protection.
4. Only the requester or admin can mark the job complete.
5. Escrow releases to the worker payout liability.
6. Platform fee is separated.
7. Tax reserve is separated from platform fee.
8. A 30% safety reserve is separated from post-tax platform fee.
9. Remaining platform amount becomes distributable profit.
10. Mock payout is sent to the worker with payout idempotency.
11. Audit records are emitted by API endpoints.
12. Finance snapshot reports marketplace volume, worker payouts, platform revenue, reserves, and AI CFO metrics without double-counting worker payouts as a platform expense.

## New API routes

- `POST /v1/commerce/jobs/fund`
- `GET /v1/commerce/jobs/:id`
- `POST /v1/commerce/jobs/:id/complete`
- `POST /v1/commerce/jobs/:id/refund`
- `POST /v1/admin/commerce/finance-snapshot`

## Safety properties

- Idempotent funding.
- Idempotent payout.
- Refund allowed only before release.
- Worker cannot self-complete a requester-funded job.
- Private job data is accessible only to the two parties or admin.
- Real payment-provider credentials are not required yet; mock/sandbox mode remains the default.

## Validation

- Full regression suite: 50/50 passed.
- HTTP smoke test: payer registration 201, worker registration 201, fund 201, worker completion blocked 403, requester completion 200, final state `PAID_OUT`.
