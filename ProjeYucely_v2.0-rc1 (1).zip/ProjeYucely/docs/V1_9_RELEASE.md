# ProjeYucely v1.9

## Payment safety hardening before Stripe test mode

- Full regression gate preserved.
- Transaction history endpoint.
- Dispute workflow with idempotency.
- Admin dispute resolution.
- Payout pending/failed recovery and reconciliation.
- Chargeback state support in commerce core.
- Reconciliation report.
- Stripe webhook HMAC verification against the raw request body.
- Duplicate webhook event suppression in the current process.
- Stripe provider skeleton and test-mode configuration placeholders.

## Current gate

Mock/sandbox commerce remains the active provider. Real Stripe keys are not required yet.
The next step is to connect the user's Stripe test-mode credentials and use Stripe Connect onboarding for payees/service providers.

## Safety note

Passing tests reduces regression risk but cannot guarantee a defect-free payment system. Live-money activation must remain disabled until Stripe test-mode payment, Connect onboarding, webhook, refund, dispute and payout tests all pass.
