# ProjeYucely v1.3 — Intelligence Layer

Added:
- Yucely Opportunity Radar intake for authorized/public API or connector signals.
- Signal classification for NEED_HELP and WORK_SEEKER intent.
- Global Voice / Issues feedback ingestion and clustering.
- Severity-weighted issue prioritization so low-volume security/payment issues can outrank cosmetic complaints.
- Feature Intelligence: most/least used features, unique users, success rate, revenue, cost and net value.
- Admin Intelligence endpoint with executive summary.
- Daily intelligence email preview endpoint (delivery provider to be connected later).
- Persistent SQLite tables for external signals, feedback and feature events.
- ONE BUTTON automatically records feature usage events.

Safety / compliance boundary:
- This release does not scrape arbitrary social media or send unsolicited DMs.
- External signals are accepted only through authorized ingestion routes intended for compliant APIs/connectors.

Verification:
- 38/38 core tests passing.
- HTTP smoke flow verified: feedback -> feature event -> authorized radar signal -> intelligence report.
