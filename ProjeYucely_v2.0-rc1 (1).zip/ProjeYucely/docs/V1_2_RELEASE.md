# ProjeYucely v1.2

Adds Do It For Me + AI Agent Orchestrator foundation.

- Internal low-risk actions may auto-execute.
- External/consequential actions default to explicit user approval.
- Agent tasks are persisted and auditable.
- Approval endpoint executes only the approved task.
- External provider calls are intentionally represented as execution intents in this version; real email/payment/booking providers will be attached later behind the same approval gate.
