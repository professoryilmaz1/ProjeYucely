# ProjeYucely v0.5

Adds an executable data/service/API foundation without external runtime dependencies.

## Added
- In-memory repository for users, availability, needs and opportunities.
- Service layer connecting persisted records to the matching and Money Mission engines.
- Minimal HTTP API with health, user, availability, need, opportunity, match and Money Mission endpoints.
- Additional end-to-end core tests.

## Deliberate limitation
The store is intentionally in-memory for this milestone. It proves contracts and workflows before a production database is selected. Production persistence, authentication, authorization, audit logging and rate limiting remain required before deployment.
