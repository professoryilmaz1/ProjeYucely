# ProjeYucely v0.8

First usable browser UI wired to the v0.7 backend.

## Included
- Login and registration
- Mobile-first ONE BUTTON screen
- Natural-language result rendering
- EARN opportunity summary
- Availability form
- Same-origin static web serving from the API
- Existing auth, policy, audit, matching, and Money Mission flows retained
