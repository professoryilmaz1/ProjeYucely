# ProjeYucely v0.3

## Implemented
- Executable ONE BUTTON intent router
- NEED, EARN, MONEY MISSION, SAVE MONEY, PLAN LIFE, WHAT IF, RELATIONSHIP MATCH and SUPPORT routes
- Amount extraction for USD/EUR/TRY
- Basic time-range and duration extraction
- Risk flags for high-risk requests, potentially discriminatory employment criteria and sensitive relationship matching
- Policy gate: ALLOW / REQUIRE_APPROVAL / BLOCK
- Workflow object with deterministic next action
- JSON workflow contract
- Zero third-party runtime dependencies
- Automated Node test suite

## Verified examples
- `Köpeğime 4 saat bakıcı lazım, $40` -> NEED -> create need / find candidates
- `Bugün saat 1-5 arası boşum para kazanmak istiyorum` -> EARN -> build availability / find opportunities
- `Cuma gününe kadar $430 lazım` -> MONEY MISSION -> build money plan
- `Evlenmek istiyorum...` -> RELATIONSHIP MATCH -> explicit approval/consent required

## Test status
6/6 automated tests passing.

## Next engineering slice
- In-memory opportunity store and candidate profiles
- Matching score engine
- NEED -> candidate shortlist
- EARN -> opportunity shortlist
- Money Mission -> schedule + earnings-plan composition
- Persistence adapter interface for future PostgreSQL
