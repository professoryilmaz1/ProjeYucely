# ProjeYucely v1.0

Adds the first integrated foundations for:
- **ProjeZZ** monthly life/budget calculation: income, expenses, balance, savings rate and deficit/tight/positive state.
- **ProjeKK Daily 3**: three prioritized daily actions driven by budget and live dashboard state.
- **AI CFO**: revenue, operating costs, payouts, refunds/fraud, tax reserve, after-tax net, 30% safety reserve, distributable profit, net margin, net/user, profit per $1 spent and automatic growth gate.

New API routes:
- `POST /v1/life/budget`
- `POST /v1/life/daily3`
- `POST /v1/admin/cfo` (admin only)
