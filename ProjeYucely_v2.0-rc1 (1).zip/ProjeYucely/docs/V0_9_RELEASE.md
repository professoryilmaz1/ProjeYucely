# ProjeYucely v0.9

## Added
- Live user dashboard endpoint: `GET /v1/dashboard`
- User metrics: open needs, availability slots, open opportunities, recent workflows
- Recent NEED list and workflow activity feed
- Mobile-first dashboard layout
- Refined ONE BUTTON / NEED / EARN presentation
- Dashboard refresh after ONE BUTTON and availability actions
- New dashboard service test

## Validation
- Core tests: 19/19 passing
- API health endpoint: 200 OK, version 0.9.0
- Web root HEAD/GET smoke test: 200 OK

## Next
- ProjeZZ life/budget foundation
- Daily 3 / ProjeKK engine
- AI CFO metrics foundation
