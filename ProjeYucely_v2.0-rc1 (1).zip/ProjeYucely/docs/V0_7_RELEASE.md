# ProjeYucely v0.7 — ONE BUTTON End-to-End

ONE BUTTON is now connected to authentication, persistent request/workflow records, the intent/policy engine, service layer, matching and Money Mission.

Flow:
`POST /v1/one-button -> auth -> request persist -> intent -> policy -> workflow persist -> NEED/EARN/MONEY action -> database/matching -> audit -> response`

Implemented outcomes:
- NEED_HELP: creates a Need and immediately returns ranked candidates.
- EARN: records availability (when a time window is present) and returns open opportunities fitting that window.
- MONEY_MISSION: builds a non-overlapping earning plan toward the requested amount.
- Sensitive flows: keep approval gates; they are not auto-executed.
- Other Life/What-If/Support routes: queued placeholders until their engines are implemented.

Security boundary remains server-side: user identity comes from the authenticated session, never from a client-supplied user id.
