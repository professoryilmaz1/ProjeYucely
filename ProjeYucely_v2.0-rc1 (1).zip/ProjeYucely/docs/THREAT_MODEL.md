# ProjeYucely Threat Model v0.2

## Crown jewels
1. Customer/worker money and ledger integrity
2. Account identity and authentication
3. Private location, finance, relationship and life data
4. Admin/control plane
5. Matching integrity and marketplace trust
6. Backups and recovery credentials

## Primary threats and required controls
| Threat | Prevent | Detect | Recover |
|---|---|---|---|
| Account takeover/phishing | Passkeys/MFA, device/risk checks, step-up auth | impossible-travel/device anomaly | revoke sessions, freeze sensitive actions |
| Payment theft | provider tokenization, least privilege, payout allowlists, idempotency | ledger reconciliation, payout anomaly | payment hold, provider dispute workflow |
| Fraud/collusion | velocity limits, trust tiers, proof rules | graph/anomaly scoring | reserve/hold, investigation |
| API abuse/bots | WAF, Turnstile, rate limits, quotas | traffic anomaly | block/reroute/degrade |
| Admin compromise | separate admin identity, hardware/passkey MFA, JIT privilege | immutable admin audit | break-glass recovery, key rotation |
| Data exfiltration | encryption, field separation, purpose-based access | DLP/query anomaly | revoke, rotate, incident response |
| Injection/AI prompt attack | tool allowlists, schema validation, content isolation | policy violations/tool anomalies | stop workflow, quarantine run |
| Supply-chain compromise | lockfiles, signed CI, dependency scanning, secret scanning | CI alerts/SBOM diff | rollback, rotate secrets |
| Region/cloud outage | multi-region cells, queues, replicated critical state | health probes | failover + replay |
| Ransomware/destructive attack | immutable isolated backups, least privilege | integrity alerts | clean-room restore |
| War/disaster/power loss | geographic separation, provider diversity | regional health | DNS/traffic failover |
| Insider abuse | least privilege, dual control for high-risk finance | audit/anomaly | revoke access, forensic trail |

## Financial safety invariants
- Ledger is double-entry and append-only; corrections use compensating entries.
- No payout without a funded/authorized obligation.
- High-risk payout/account changes require step-up authentication and cooling-off/risk policy.
- Provider webhooks are signed, deduplicated and replay-safe.
- Daily automated reconciliation: provider balances vs internal ledger.

## AI agent safety invariants
- Agents never receive unrestricted infrastructure or bank credentials.
- Every tool has explicit scopes, budgets and rate limits.
- High-risk actions require policy-engine approval; owner approval above configured thresholds.
- External text is untrusted data, never executable instruction.
- Agent actions are logged with model/version, policy decision and outcome.

## Recovery objectives (initial targets)
- Financial ledger/control plane: RPO <= 5 min, RTO <= 30 min.
- Core marketplace: RPO <= 15 min, RTO <= 60 min.
- Analytics/feedback: RPO <= 24 h, RTO <= 24 h.
Targets must be validated by restore/failover drills before scale claims.
