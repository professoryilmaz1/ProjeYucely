# ProjeYucely v1.7

- Full regression gate introduced: core tests + API syntax + web syntax must pass before packaging.
- Payment foundation added with double-entry style ledger entries, escrow state, refund/release state machine, idempotency, platform fee allocation, tax reserve, and 30% safety reserve allocation.
- Mock payment provider added for sandbox logic without real Stripe keys.
- Real Stripe adapter intentionally deferred until owner supplies/authorizes sandbox credentials; no secret is stored in source.
