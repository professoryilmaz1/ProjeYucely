# ProjeYucely v1.6

## Added
- ProjeZZ Life Center in web dashboard.
- Live monthly budget analysis card.
- Daily 3 visual action cards.
- What If scenario simulator UI and API endpoint.
- Fix My Day UI and API endpoint.
- AI CFO admin status card.
- Mobile responsive Life Center layout.

## API
- `POST /v1/life/what-if`
- `POST /v1/life/fix-my-day`

## Validation
- Core tests: 42/42 passing.
- HTTP smoke: health 200, web 200, budget 200, what-if 200, fix-my-day 200.
