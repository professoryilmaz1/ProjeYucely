# ProjeYucely v0.6

Security/data foundation release.

- SQLite WAL persistence (development-grade local persistence)
- Password hashing with Node scrypt
- Random bearer sessions stored only as SHA-256 token hashes
- Authorization: user-scoped write operations
- IP rate limiting
- 256 KB request body cap
- Immutable-style append-only audit events at application layer
- Security response headers and no-store API responses
- Protected admin audit endpoint

## Production note
SQLite is intentionally a local/dev persistence layer. Production will migrate the same store contract to managed PostgreSQL with multi-region strategy, backups, row-level controls, secret manager and edge WAF.
