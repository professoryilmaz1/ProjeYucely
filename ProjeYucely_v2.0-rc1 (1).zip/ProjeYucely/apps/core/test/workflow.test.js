import test from 'node:test';
import assert from 'node:assert/strict';
import { createWorkflow, routeIntent } from '../src/index.js';

test('routes a local help request to NEED', () => {
  const result = routeIntent('Köpeğime 4 saat bakıcı lazım, $40');
  assert.equal(result.primary_intent, 'NEED_HELP');
  assert.equal(result.route, 'need_agent');
  assert.equal(result.entities.amount, 40);
  assert.equal(result.entities.duration_hours, 4);
});

test('routes availability to EARN', () => {
  const result = routeIntent('Bugün saat 1-5 arası boşum para kazanmak istiyorum');
  assert.equal(result.primary_intent, 'EARN');
  assert.equal(result.route, 'earn_agent');
  assert.equal(result.entities.start_time, '01:00');
  assert.equal(result.entities.end_time, '05:00');
});

test('routes money deadline to MONEY_MISSION', () => {
  const result = routeIntent('Cuma gününe kadar $430 lazım');
  assert.equal(result.primary_intent, 'MONEY_MISSION');
  assert.equal(result.route, 'money_agent');
  assert.equal(result.entities.amount, 430);
});

test('relationship request requires explicit approval', () => {
  const workflow = createWorkflow({ id: 'r1', user_id: 'u1', text: 'Evlenmek istiyorum, bana uygun biriyle eşleştir' });
  assert.equal(workflow.intent.primary_intent, 'RELATIONSHIP_MATCH');
  assert.equal(workflow.state, 'NEEDS_APPROVAL');
  assert.equal(workflow.next_action, 'request_user_approval');
});

test('potential discriminatory employment request pauses for review', () => {
  const workflow = createWorkflow({ id: 'r2', user_id: 'u1', text: 'Markete 1 saat bakacak kadın lazım $20' });
  assert.equal(workflow.intent.primary_intent, 'NEED_HELP');
  assert.equal(workflow.state, 'NEEDS_APPROVAL');
});

test('ordinary need request becomes ready workflow', () => {
  const workflow = createWorkflow({ id: 'r3', user_id: 'u1', text: 'Yarın evdeki masayı taşımaya yardım lazım $30' });
  assert.equal(workflow.state, 'READY');
  assert.equal(workflow.next_action, 'create_need_and_find_candidates');
});
